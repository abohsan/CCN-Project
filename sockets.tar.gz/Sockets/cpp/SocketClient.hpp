#ifndef __SOCKET_CLIENT_HPP__
#define __SOCKET_CLIENT_HPP__

#include <iostream> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <unistd.h> 

class SocketClient {
	public:
		SocketClient(const std::string &ip, int port) : m_ip(ip), m_port(port), m_socket(0) { connect(); }
		~SocketClient() { disconnect(); }
		bool send(const std::string &msg);
		std::string read();
	protected:
		void warn(const std::string &msg) const;
		bool connect();
		bool disconnect();
	private:
		std::string m_ip;
		int m_port;
		int m_socket;
};

#endif