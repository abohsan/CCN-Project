#include <iostream>
#include <fstream>
#include <string>
#include "SocketClient.hpp"

int main(int argc, char const *argv[]) { 
	SocketClient client("127.0.0.1", 8080);
	
	std::cout << "Talk to the server typing 'bye', 'read' or any other messages..." << std::endl;
	
	std::string cmd;
	while (cmd != "bye") {
		std::cout << "?> ";
		std::getline(std::cin, cmd);
		
		if (cmd == "read") {
			std::ifstream file("beowulf.txt");
			std::string str;
			while (std::getline(file, str))
				client.send(str);
		}
		else
			client.send(cmd);	 
    }
    
    std::cout << "Bye!" << std::endl;
    return 0; 
} 